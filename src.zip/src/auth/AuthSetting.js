import firebase from 'firebase/app';

var provider = new firebase.auth.GoogleAuthProvider();

export default provider;